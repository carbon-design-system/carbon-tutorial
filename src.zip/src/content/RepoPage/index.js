import RepoPage from './RepoPage';
export default RepoPage;
